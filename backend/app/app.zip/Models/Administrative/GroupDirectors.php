<?php

namespace App\Models\Administrative;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class GroupDirectors extends Model
{
    use HasFactory;
    public $table = "dir_grupo";
}
