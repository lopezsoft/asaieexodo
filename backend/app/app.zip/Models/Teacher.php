<?php

namespace App\Models;

use App\Models\User;

class Teacher extends User
{

}
