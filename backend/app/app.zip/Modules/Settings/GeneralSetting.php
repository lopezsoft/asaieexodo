<?php
namespace App\Modules\Settings;
use App\Common\MessageExceptionResponse;
use App\Modules\School\SchoolQueries;
use App\Traits\MessagesTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class GeneralSetting
{
    use MessagesTrait;
    public static function getGeneralSettingByGrade($school, $gradeId = 5): ?object
    {
        $db     = $school->db;
        $year   = $school->year;
        $query  = DB::table("{$db}config001","t")
            ->where('t.year', $year);
        if ($gradeId > 0) {
            $query->where('t2.id_grado', $gradeId)
                ->leftJoin($db."grados_agrupados AS t1", "t.id_grupo_grados", "=", "t1.id")
                ->leftJoin($db."aux_grados_agrupados AS t2", "t2.id_grado_agrupado", "=", "t1.id");
            return $query->first();
        }
        return $query->get();
    }

    /**
     * @throws \Exception
     */
    public static function generalSetting(Request $request): \Illuminate\Http\JsonResponse
    {
        try {
            $school = SchoolQueries::getSchoolRequest($request);
            $db     = $school->db;
            $query  = DB::table("{$db}config001", "t1")
                        ->selectRaw("t1.*, t2.nombre_grado_agrupado")
                        ->leftJoin("{$db}grados_agrupados as t2","t1.id_grupo_grados","=", "t2.id")
                        ->where("t1.year", $school->year);
            return self::getResponse([
                'records' => $query->paginate()
            ]);
        } catch (\Exception $e) {
            return MessageExceptionResponse::response($e);
        }
    }
}
