Ext.define('globales.SetUrls', {
	singleton 	: true,
	UrlBase 	: "http://sme2019/index.php/",
	UrlLocation : "http://sme2019"
});