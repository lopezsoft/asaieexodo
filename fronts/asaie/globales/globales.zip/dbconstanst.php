<?php
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 define('DATABASE_NAME','myschoolsadmin');
 define('HOST_NAME','127.0.0.1');
 define('USER_NAME','root');
 define('USER_PASSWORD','');
 define('PORT','3307');
 define('DATABASE_DRIVE','MariaDB'); // MariaDB, MySQL
 define('BASE_URL_INDEX','http://asaie/');
 